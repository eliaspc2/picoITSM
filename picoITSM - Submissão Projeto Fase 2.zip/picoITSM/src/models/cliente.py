# src/models/cliente.py

class Cliente:
    def __init__(self, nome, email, telefone=""):
        self.nome = nome
        self.email = email
        self.telefone = telefone